import java.util.ArrayList;
import java.util.List;

public class UserDB {
    List<User> userDBS = new ArrayList<>();

    UserDB(){
        userDBS.add(new User("livanhaddish","abcd1234"));
        userDBS.add(new User("livan","1111"));
    }

    public List<User> getUserDBS() {
        return userDBS;
    }
}
